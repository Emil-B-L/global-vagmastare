# Portföljdashboard

En sammanslagen app med fyra flikar: Portföljanalys, Optimering (max Sharpe),
Innehav (topp 100 + cirkeldiagram) och NAV & Rebalansering (Fear & Greed-index
+ fondkurser, uppdaterade dagligen via GitHub Actions).

## Snabbstart — lägg in detta i ditt GitHub-repo

1. Skapa ett nytt repo på GitHub (eller använd ett befintligt).
2. Lägg in mappstrukturen exakt som den ligger här:
   ```
   .github/workflows/update-data.yml
   scripts/fetch_fear_greed.py
   scripts/fetch_fund_nav.py
   data/fear_greed.json
   data/fund_nav.json
   docs/index.html
   ```
3. Pusha till `main`-branchen.
4. Gå till repots **Settings → Pages**. Under "Build and deployment",
   välj **Deploy from a branch**, branch = `main`, mapp = `/docs`. Spara.
5. Efter ~1 minut är appen live på `https://<ditt-användarnamn>.github.io/<repo-namn>/`.

## Aktivera den dagliga datahämtningen

Workflowet (`.github/workflows/update-data.yml`) är redan konfigurerat att
köra automatiskt varje vardag kl 17:30 UTC. Du behöver inte göra något extra
för att det ska börja köra på schema — GitHub Actions aktiveras automatiskt
så fort filen finns på `main`.

**Testa det direkt utan att vänta på schemat:** gå till repots **Actions**-flik,
klicka på "Uppdatera portföljdata" i listan till vänster, klicka **Run workflow**.

## Status just nu — vad fungerar och vad är platshållare

**Fear & Greed Index** — fungerar. Skriptet hämtar CNN:s publika
dataviz-endpoint utan API-nyckel. Detta är samma mönster flera öppna
projekt använder (se `fear-and-greed` på PyPI). Endpointen är inte officiellt
dokumenterad av CNN och kan i teorin ändras, men har varit stabil länge.

**Fondkurser (NAV)** — PLATSHÅLLARE. Vi har ännu inte bestämt källa.
Se kommentarerna i `scripts/fetch_fund_nav.py` för avvägningarna mellan:
- Fondbolagens egna sidor (kräver separat scraping-logik per fondbolag)
- En finansdataleverantör med gratis-tier (osäkert om alla 10 fonder,
  särskilt de svenska/nischade, finns där)

Tills källan är vald skriver skriptet ut placeholder-NAV (100.00) för
samtliga fonder, så att resten av appen (NAV-flik, rebalanseringslogik)
går att bygga och testa redan nu.

**Viktdrift / rebalanseringssignal** — kräver minst två historiska
NAV-datapunkter per fond för att kunna räkna ut hur vikterna glidit.
Detta byggs ut i nästa steg, när NAV-källan är på plats och har samlat
in några dagars data.

## Nästa steg (i ordning)

1. Bestäm källa för fondkurser → uppdatera `fetch_fund_nav.py`
2. Låt Action köra några dagar så historik byggs upp
3. Implementera viktdrift-beräkning i NAV-fliken (jämför dagens vikt mot målvikt)
4. Implementera rebalanseringslarm baserat på tröskeln du sätter i UI
5. (Eventuellt) Lägg till valutaomräkning för Robeco (EUR) och BGF (USD) mot SEK

## Teknisk not

Frontend är en enda statisk HTML-fil (`docs/index.html`) som laddar React,
Recharts och Babel från CDN och kompilerar JSX i webbläsaren. Inga byggverktyg,
inget npm-steg — det är medvetet enkelt så att GitHub Pages kan servera den
direkt utan något build-steg i Actions.
