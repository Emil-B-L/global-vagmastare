"""
Hämtar dagliga NAV-kurser för portföljens 10 fonder.

STATUS: PLATSHÅLLARE. Källa för fondkurser är INTE bestämd än.
Se README.md för diskussionen om alternativ:
  - Fondbolagens egna sidor (kräver scraping per fond, olika HTML-struktur var)
  - Finansdataleverantör med gratis-tier (Financial Modeling Prep, Twelve Data) —
    osäkert om alla 10 fonder finns där (flera är svenska/nischade fonder)
  - Morningstar (har vissa öppna datapunkter men inte ett stabilt gratis API)

Tills källan är vald skriver detta skript ENDAST tidigare kända NAV-värden
(manuellt inlagda i FALLBACK_NAV nedan) till data/fund_nav.json, så att
resten av pipelinen (dashboard, viktberäkning) går att bygga och testa
redan nu utan att blockeras på datakällan.

NÄSTA STEG: byt ut `fetch_nav_for_fund()` mot riktiga anrop när källa är vald.
"""
import json
import sys
from datetime import datetime, timezone

OUTPUT_PATH = "data/fund_nav.json"

# Fondernas målvikter (från portföljanalysen) + senast kända NAV som fallback.
# NAV-värdena nedan är PLACEHOLDERS — ersätt med verklig data när källan är klar.
FUNDS = [
    {"id": "avanza", "name": "Avanza Zero", "target_weight": 9.0, "fallback_nav": 100.00, "currency": "SEK"},
    {"id": "carnegie", "name": "Carnegie US Small & Micro Cap", "target_weight": 6.0, "fallback_nav": 100.00, "currency": "SEK"},
    {"id": "finserve", "name": "Finserve Global Security Fund I SEK R", "target_weight": 14.0, "fallback_nav": 100.00, "currency": "SEK"},
    {"id": "hb_europa", "name": "Handelsbanken Europa Index (A1 SEK)", "target_weight": 16.0, "fallback_nav": 100.00, "currency": "SEK"},
    {"id": "hb_usa", "name": "Handelsbanken USA Index (A1 SEK)", "target_weight": 21.0, "fallback_nav": 100.00, "currency": "SEK"},
    {"id": "spiltan_inv", "name": "Spiltan Aktiefond Investmentbolag", "target_weight": 11.0, "fallback_nav": 100.00, "currency": "SEK"},
    {"id": "spiltan_sma", "name": "Spiltan Småbolag", "target_weight": 5.0, "fallback_nav": 100.00, "currency": "SEK"},
    {"id": "hb_tillvaxt", "name": "Handelsbanken Tillväxtmarknad Tema (A1 SEK)", "target_weight": 13.0, "fallback_nav": 100.00, "currency": "SEK"},
    {"id": "robeco", "name": "Robeco Smart Energy D-EUR Capitalisation", "target_weight": 3.0, "fallback_nav": 100.00, "currency": "EUR"},
    {"id": "bgf", "name": "BGF World Gold Fund A2", "target_weight": 2.0, "fallback_nav": 100.00, "currency": "USD"},
]


def fetch_nav_for_fund(fund):
    """PLATSHÅLLARE. Returnerar fallback-NAV tills en riktig datakälla är vald.

    När källan är bestämd: gör ett HTTP-anrop här och returnera (nav, is_live=True).
    """
    return fund["fallback_nav"], False


def main():
    results = []
    any_live = False

    for fund in FUNDS:
        nav, is_live = fetch_nav_for_fund(fund)
        any_live = any_live or is_live
        results.append({
            "id": fund["id"],
            "name": fund["name"],
            "target_weight": fund["target_weight"],
            "currency": fund["currency"],
            "nav": nav,
            "is_live_data": is_live,
        })

    output = {
        "funds": results,
        "data_source_status": "PLACEHOLDER — riktig källa ej kopplad än",
        "fetched_at": datetime.now(timezone.utc).isoformat(),
    }

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print("OK: skrev platshållar-NAV för", len(results), "fonder")
    print("OBS: data_source_status =", output["data_source_status"])


if __name__ == "__main__":
    main()
