"""
Hämtar CNN Fear & Greed Index och sparar som JSON.
Körs dagligen via GitHub Actions (.github/workflows/update-data.yml).

CNN publicerar sin egen data på en publik dataviz-endpoint som inte
kräver API-nyckel. Detta är ett oficiellt scraping-mönster som flera
open-source-projekt (t.ex. fear-and-greed på PyPI) använder.
"""
import json
import sys
import urllib.request
from datetime import datetime, timezone

CNN_URL = "https://production.dataviz.cnn.io/index/fearandgreed/graphdata"
OUTPUT_PATH = "data/fear_greed.json"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Accept": "application/json",
}


def fetch_fear_greed():
    req = urllib.request.Request(CNN_URL, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=20) as resp:
        raw = resp.read()
    return json.loads(raw)


def extract_summary(raw):
    """CNN:s svar innehåller 'fear_and_greed' (nuvarande) samt historiska serier
    för momentum, stock_price_strength, etc. Vi plockar ut det vi behöver."""
    current = raw.get("fear_and_greed", {})

    score = current.get("score")
    rating = current.get("rating")
    timestamp = current.get("timestamp")

    # Historiska jämförelsepunkter om de finns
    prev_close = current.get("previous_close")
    prev_week = current.get("previous_1_week")
    prev_month = current.get("previous_1_month")
    prev_year = current.get("previous_1_year")

    return {
        "score": score,
        "rating": rating,
        "source_timestamp": timestamp,
        "previous_close": prev_close,
        "previous_1_week": prev_week,
        "previous_1_month": prev_month,
        "previous_1_year": prev_year,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
    }


def main():
    try:
        raw = fetch_fear_greed()
        summary = extract_summary(raw)
    except Exception as e:
        print(f"FEL vid hämtning av Fear & Greed Index: {e}", file=sys.stderr)
        # Skriv en felpost istället för att krascha hela workflowet,
        # så att frontend kan visa "data ej tillgänglig" snyggt.
        summary = {
            "error": str(e),
            "fetched_at": datetime.now(timezone.utc).isoformat(),
        }
        with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        sys.exit(1)

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(f"OK: Fear & Greed = {summary['score']} ({summary['rating']})")


if __name__ == "__main__":
    main()
